#pragma once
class cubeNoOOP
{
};

