#pragma once
class cube
{
};

